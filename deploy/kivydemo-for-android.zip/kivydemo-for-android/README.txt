Copy all the directories to /sdcard/kivy
Then run the launcher!
